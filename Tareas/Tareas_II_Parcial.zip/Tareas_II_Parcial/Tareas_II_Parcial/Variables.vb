﻿Module Variables
#Region "Arreglos Bidimencionales (Banco)"
    Public usuario(10, 10) As String
    Public valores(10, 2)
#End Region
End Module
